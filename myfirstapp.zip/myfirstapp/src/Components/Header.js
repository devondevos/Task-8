import React, { Components } from 'react';
import ReactDOM from 'react-dom';
import logo from './logo.png';
import profile from './profile.png';

class Header extends React.Component {
  render() {
    return (
    	<div>
    	<header className="header">
    	<img src={logo} className="App-logo" alt="Arsenal logo" /> 	
    	</header>
    	</div>
    );
  }
}
{/*create a header that can be recalled anytime*/}
export default Header;
