import React, { Components } from 'react';
import ReactDOM from 'react-dom';
import Modal from 'react-modal';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Home from './home.webp';
import Away from './away.webp';
import Hoodie from './hoodie.webp';

class Body extends React.Component {
  render() {
    return (
    	<Container>
    	<Row>
    	<Col md={3} id="items" className="card">
    	<a href="">
    	<img src={Home} className="arsenal" /> <h3>R 899.95</h3>
    	<h5>Men's Adidas Arsenal Home Jersey</h5>
    	</a>
    	</Col>
    	<Col md={3} id="items" className="card">
    	<a href="">
    	<img src={Away} className="arsenal" /> <h3>R 899.95</h3>
    	<h5>Men's Adidas Arsenal Away Jersey</h5>
    	</a>
    	</Col>
    	<Col md={3} id="items" className="card">
    	<a href="">
    	<img src={Hoodie} className="arsenal" /> <h3>R 1 999.95</h3>
    	<h5>Men's Adidas Arsenal Hoodie</h5>
    	</a>
    	</Col>
    	</Row>
    	</Container>
    );
  }
}
{/*use bootstrap to position items on the webpage and use links*/}
export default Body;
