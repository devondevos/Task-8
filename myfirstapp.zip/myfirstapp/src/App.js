import React from 'react';
import ReactDOM from 'react-dom';
import Modal from 'react-modal';
import {BrowserRouter, Route} from 'react-router-dom';
import Bootstrap from 'react-bootstrap';
import Header from './Components/Header';
import Body from './Components/Body';
import Login from './Components/Login';
import profilePic from './Components/profile.png';
import './App.css';
{/*link all your articles, all the js file and extras you use*/}

function signedIn() {
	alert("Welcome. Ignore the next pop-up message!");
}

function signIn() {
	alert("Please sign in");
}

function signUp() {
	alert("Customize your profile. Ignore the next pop-up message!");
}

function loginProfile() {
	alert(Login);
}

{/*use alerts that is showed when the user clicks the sign-in, sign-out and when the page loads*/}

function App() {
  return (
    <div className="App">
      <header className="App-header">
      	<div className="signIn">
      		<img onLoad={signIn} onClick={loginProfile} src={profilePic} className="profile" /> {/*import an image*/} <br/>
      		<button onClick={signedIn} className="sign">Sign in</button> {/*make 2 buttons that uses a function*/} <br/>
      		<button onClick={signUp} className="sign">Sign up</button>
      	</div>
      		<Header />
      </header>
      <body className="App-body">
      	<nav id="nav">
      		<ul>
      			<a href=""><li>About Us</li></a>
      			<a href=""><li>Catalogue</li></a>
      			<a href=""><li>Home Page</li></a>
      		</ul>
      	</nav>
      	<Body />
      	<p>Sorry for the inconvenience, the repeated 'sign in' is for security reasons.</p><br/>
      </body>
    <div>
    	<footer>CopyRight&copy; of Devon De Vos and Arsenal FC</footer>
    </div>
    </div>
  );
}

export default App; {/*export the app file*/}
